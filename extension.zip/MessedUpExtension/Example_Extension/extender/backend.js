// const buttonpressed = document.getElementById("button-click");

// import { Loader } from "@googlemaps/js-api-loader"
// buttonpressed.addEventListener("click", () => {
//     chrome.tabs.query({active: true, currentWindow: true}, tabs => {
//         const url = tabs[0].url;
//         let requestText = url;
//         console.log(url);
//         fetch("http://localhost:8000/", { 
//           method: "POST",
//           //mode: 'cors',
//         headers: {
//           "Content-Type":"application/json"
//         },
//         body: JSON.stringify({
//           request: requestText
//         })
//       })
//       .then(response => response.json())
//       .then(data => {
//         const loader = new Loader({
//           apiKey: "AIzaSyDK8ejE1TPMMIG1hqNVMXiHNxh5Vih4nq4",
//           version: "weekly",
//           ...additionalOptions,
//         });
        
//         loader.load().then(() => {
//           map = new google.maps.Map(document.getElementById("map"), {
//             center: { lat: -34.397, lng: 150.644 },
//             zoom: 8,
//           });
//         });
        
//         //console.log(data.response);
//       });
//     });
// })

function sendUrl(e){
  // send the url to the python endpoint
  var the_url = window.location.href;
  console.log(the_url);

          fetch("http://localhost:8000/", { 
          method: "POST",
          mode: 'no-cors',
        headers: {
          "Content-Type":"application/json"
        },
        body: JSON.stringify({
          request: the_url
        })
      })
      .then(response => {
        console.log(response.json());
        addMapOverlay({lat:0, lon: 0});
      })
}

function addUI(e){
  var button = document.createElement("button");
  button.innerText = "test";
  button.onclick = sendUrl;

  const mapTarget = document.createElement("div");
  mapTarget.id = "target_for_map";
  document.getElementsByClassName("game-layout__top-hud")[0].appendChild(button);
  document.getElementsByClassName("game-layout__top-hud")[0].appendChild(mapTarget);
  console.log("adding UI elements");
}
// document.addEventListener("load", addUI);

function addMapOverlay(mapOptions){
  const loader = new google.maps.plugins.loader.Loader(
    {apiKey: "AIzaSyDK8ejE1TPMMIG1hqNVMXiHNxh5Vih4nq4",
     version: "weekly"})

  loader.load().then((google) => new google.maps.Map(document.getElementById("target_for_map"), mapOptions))
}

addUI();


console.log("loaded backend.js");