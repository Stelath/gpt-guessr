from flask import Flask, request
import json
import subprocess

app = Flask(__name__)

@app.route("/", methods=["POST"])
def handle_request():
    request_data = request.get_json()
    request_text = request_data.get("request", "")
    # Run the Python script with the request text
    output = subprocess.run(["python", ".\selProgram.py", request_text], capture_output=True, text=True)
    response_data = { "response": output.stdout }
    return json.dumps(response_data), 200

if __name__ == "__main__":
    app.run(debug=True)
